﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
        // GET: api/<StudentController>
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return studentList.ToList();
        }

        public static List<string> aliceHobbies = new List<string>()
        {"Reading","Swimming","Coding" };
        public static List<string> bobHobbies = new List<string>()
         {"Painting","Dancing","Singing"};
        public static List<Student> studentList = new List<Student>()
        {
            new Student { Id = 1, Name="Alice", Age=25, Hobbies=aliceHobbies },
            new Student { Id = 1, Name="Bob", Age=25, Hobbies=bobHobbies},
        };


        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            Student studentObj = (from student in studentList
                                  where student.Id == id
                                  select student).SingleOrDefault();
            return studentObj;
        }
    }
}