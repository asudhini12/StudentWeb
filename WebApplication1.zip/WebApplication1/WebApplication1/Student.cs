using System;
using System.Collections.Generic;

namespace WebApplication1
{
    public class Student
    { 
        public int Id { get; set; }
        public int Age { get; set; }
        public List<string> Hobbies { get; set; }
        public string Name { get; set; }
    }
}
